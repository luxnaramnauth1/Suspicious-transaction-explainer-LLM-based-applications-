"""Create the suspicious-activity dataset: the base transactions plus four synthetic typologies.

Input:  data/base_transactions.csv   (synthetic, from the agentic banking project)
Output: data/suspicious_transactions.csv
Run:    python scripts/make_dataset.py
"""
import csv
import os

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, '..', 'data', 'base_transactions.csv')
OUT = os.path.join(HERE, '..', 'data', 'suspicious_transactions.csv')

with open(BASE, newline='') as f:
    rows = list(csv.DictReader(f))  # read the base feed as dictionaries

def add(acc, cus, date, time, kind, amount, ccy, cat, channel, branch, status='SUCCESS'):
    """Append one synthetic transaction; balances are recomputed later."""
    rows.append({'transaction_id': '', 'account_id': acc, 'customer_id': cus, 'transaction_date': date,
                 'transaction_time': time, 'transaction_type': kind, 'amount': f'{amount:.2f}', 'currency': ccy,
                 'merchant_category': cat, 'channel': channel, 'branch_code': branch, 'balance_after': '0.00',
                 'status': status})

# Typology 1: structuring. Four transfers just under the 10,000 MUR review threshold within a week.
for day, amt in [('2026-09-14', 9800), ('2026-09-15', 9900), ('2026-09-16', 9650), ('2026-09-17', 9990)]:
    add('ACC2003', 'CUS603', day, '10:15:00', 'DEBIT', amt, 'MUR', 'Transfer Out', 'TRANSFER', 'BR02')

# Typology 2: pass-through. The September salary is sent on almost in full the next day.
salary = max(float(r['amount']) for r in rows
             if r['account_id'] == 'ACC2001' and r['transaction_date'] == '2026-09-25' and r['transaction_type'] == 'CREDIT')
add('ACC2001', 'CUS601', '2026-09-26', '09:40:00', 'DEBIT', round(salary * 0.92, 2), 'MUR', 'Transfer Out', 'TRANSFER', 'BR02')

# Typology 3: rapid, late-night spending. Four card payments within 40 minutes, after 23:00.
for tm, amt in [('23:10:05', 2850), ('23:22:41', 3120), ('23:31:17', 2990), ('23:45:09', 3400)]:
    add('ACC2004', 'CUS604', '2026-08-30', tm, 'DEBIT', amt, 'MUR', 'Electronics', 'ONLINE', 'BR03')

# Typology 4: retry after a failed payment. A failed debit is followed by the same amount succeeding an hour later.
add('ACC2002', 'CUS602', '2026-09-08', '14:02:10', 'DEBIT', 5000, 'MUR', 'Insurance', 'TRANSFER', 'BR02', 'FAILED')
add('ACC2002', 'CUS602', '2026-09-08', '15:05:33', 'DEBIT', 5000, 'MUR', 'Insurance', 'TRANSFER', 'BR02', 'SUCCESS')

# Keep rows in time order, then recompute running balances so every account stays consistent.
def stamp(r):  # sort key: ISO date then time, as text (an impossible date such as 2026-09-31 still sorts without error)
    return (r['transaction_date'], r['transaction_time'])
def num(x):  # text to float, or None when the value is blank or invalid (the base feed has a few on purpose)
    try:
        return float(x)
    except (TypeError, ValueError):
        return None
def kind_of(r):  # normalise the type text, for example 'debit ' becomes 'DEBIT'
    return (r['transaction_type'] or '').strip().upper()
opening = {}
for r in rows:  # the opening balance is the balance before each account's first valid row
    acc = r['account_id']
    amt, bal = num(r['amount']), num(r['balance_after'])
    if acc and acc not in opening and amt is not None and bal is not None:
        opening[acc] = bal - amt if kind_of(r) == 'CREDIT' else bal + amt
rows.sort(key=stamp)
running = dict(opening)
for r in rows:  # walk the feed in time order and keep each account's running balance
    acc = r['account_id']
    amt = num(r['amount'])
    if not acc or acc not in running or amt is None:  # rows without an account or amount keep their values
        continue
    if r['status'] == 'SUCCESS' and kind_of(r) == 'CREDIT':
        running[acc] = round(running[acc] + amt, 2)
    elif r['status'] == 'SUCCESS' and kind_of(r) == 'DEBIT':
        running[acc] = round(running[acc] - amt, 2)
    r['balance_after'] = f'{running[acc]:.2f}'  # failed rows keep the balance unchanged
for i, r in enumerate(rows, start=1):  # sequential IDs in time order
    r['transaction_id'] = f'TXN{i:04d}'

fields = ['transaction_id', 'account_id', 'customer_id', 'transaction_date', 'transaction_time', 'transaction_type',
          'amount', 'currency', 'merchant_category', 'channel', 'branch_code', 'balance_after', 'status']
with open(OUT, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)
print('wrote', OUT, 'rows:', len(rows))

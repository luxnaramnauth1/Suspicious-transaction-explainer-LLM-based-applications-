# make_demo.py - turn the recorded browser frames into a captioned demo MP4.
# Reads manifest.json (written by record_demo.mjs) and adds a caption strip under each frame.
import json  # read the frame manifest
import os  # build paths and check folders
import shutil  # remove the temporary frame folder
import subprocess  # run ffmpeg to encode the MP4
import tempfile  # create a temporary folder for captioned frames
from PIL import Image, ImageDraw, ImageFont  # draw captions under each frame

HERE = os.path.dirname(os.path.abspath(__file__))  # folder that holds this script
PROJECT = os.path.dirname(HERE)  # project root, one level up from scripts/
RAW_DIR = os.environ.get('RAW_DIR', os.path.join(PROJECT, 'demo', 'raw'))  # folder with the recorded frames and manifest.json
OUT_FILE = os.path.join(PROJECT, 'demo', 'suspicious_explainer_demo.mp4')  # final video file
FPS = 6  # frames per second; 305 frames gives about 50 seconds
STRIP_H = 64  # height in pixels of the caption strip under each frame
FFMPEG = os.environ.get('FFMPEG', 'ffmpeg')  # ffmpeg command, can be overridden with an env var

def load_font(size):  # try a common font, fall back to Pillow's built-in font
    for name in ['DejaVuSans.ttf', 'Arial.ttf', 'LiberationSans-Regular.ttf']:  # font names to try
        try:  # attempt to load the font file
            return ImageFont.truetype(name, size)  # return the first font that loads
        except OSError:  # font not installed, try the next name
            continue  # move on to the next candidate
    return ImageFont.load_default()  # last resort: Pillow's default font

def caption_frame(src, caption, dst, font):  # add a caption strip under one frame and save it
    frame = Image.open(src).convert('RGB')  # open the screenshot as RGB
    w, h = frame.size  # width and height of the screenshot
    canvas = Image.new('RGB', (w, h + STRIP_H), (15, 23, 42))  # dark strip canvas, same width as the frame
    canvas.paste(frame, (0, 0))  # place the screenshot at the top
    draw = ImageDraw.Draw(canvas)  # drawing handle for the caption strip
    draw.text((24, h + STRIP_H // 2), caption, fill=(241, 245, 249), font=font, anchor='lm')  # caption text, vertically centred
    canvas.save(dst)  # write the captioned frame as PNG

def main():
    manifest_path = os.path.join(RAW_DIR, 'manifest.json')  # location of the frame list
    if not os.path.exists(manifest_path):  # stop with a clear message if the recording is missing
        raise SystemExit(f'Missing {manifest_path}. Run record_demo.mjs first.')  # explain what to run
    with open(manifest_path, encoding='utf-8') as f:  # open the manifest
        frames = json.load(f)  # list of {file, caption} entries
    os.makedirs(os.path.dirname(OUT_FILE), exist_ok=True)  # create the demo folder if needed
    font = load_font(24)  # caption font size
    tmp = tempfile.mkdtemp(prefix='demo_frames_')  # temporary folder for captioned frames
    try:  # always clean up the temporary folder
        for i, item in enumerate(frames):  # go through every recorded frame in order
            src = item['file'] if os.path.isabs(item['file']) else os.path.join(RAW_DIR, os.path.basename(item['file']))  # resolve the frame path
            caption_frame(src, item['caption'], os.path.join(tmp, f'{i:05d}.png'), font)  # write the captioned copy
        cmd = [FFMPEG, '-y', '-framerate', str(FPS), '-i', os.path.join(tmp, '%05d.png'),  # read the frames in order
               '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '23', '-movflags', '+faststart',  # widely playable H.264 MP4
               OUT_FILE]  # output path
        subprocess.run(cmd, check=True, capture_output=True)  # encode the video
    finally:  # runs even if encoding fails
        shutil.rmtree(tmp, ignore_errors=True)  # delete the temporary frames
    print(f'Wrote {OUT_FILE} | frames: {len(frames)} | duration: about {len(frames) / FPS:.0f} s')  # report the result

if __name__ == '__main__':  # run only when executed directly
    main()  # build the video

// Records a scripted analyst session in the real interface and saves frames for the demo video.
// Usage:  node record_demo.mjs            (uses @sparticuz/chromium, or CHROME_PATH if set)
// Then:   python make_demo.py             (adds captions and encodes the MP4 with ffmpeg)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer-core';

const here = path.dirname(fileURLToPath(import.meta.url));
const APP_DIR = process.env.APP_DIR || path.resolve(here, '..', 'app');  // folder that holds index.html
const APP = 'file://' + path.join(APP_DIR, 'index.html');
const RAW = process.env.RAW_DIR || path.resolve(here, '..', 'demo', 'raw');  // where the raw frames are written
fs.rmSync(RAW, { recursive: true, force: true });
fs.mkdirSync(RAW, { recursive: true });

let executablePath = process.env.CHROME_PATH;
let args = ['--no-sandbox'];
if (!executablePath) {  // fall back to a headless Chromium shipped with npm
  const chromium = (await import('@sparticuz/chromium')).default;
  executablePath = await chromium.executablePath();
  args = chromium.args;
}
const browser = await puppeteer.launch({ executablePath, args, headless: true, defaultViewport: { width: 1280, height: 720 } });
const page = await browser.newPage();
await page.goto(APP, { waitUntil: 'load' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'load' });

const manifest = [];  // one entry per frame: the image file and the caption shown under it
let caption = '';
let frame = 0;
async function snap(n = 1) {  // capture n frames with the current caption
  for (let i = 0; i < n; i++) {
    const file = path.join(RAW, `f${String(frame++).padStart(5, '0')}.png`);
    await page.screenshot({ path: file });
    manifest.push({ file, caption });
  }
}
async function say(text, holdFrames = 12) {  // show a caption, then hold on the current screen
  caption = text;
  await snap(holdFrames);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 1. The queue
await say('1  Open the review queue. Cases are sorted by risk, highest first.', 18);
// 2. Filter
await say('2  Filter to High risk. Structuring and pass-through cases come first.', 6);
await page.select('#fRisk', 'High');
await snap(12);
// 3. Open a case
await say('3  Click a case. The panel shows the facts and why each rule fired.', 6);
await page.click('tr.case[data-id="CASE-0002"]');
await snap(18);
// 4. Read the analyst note and the account activity
await say('4  Read the analyst note. It is a draft written only from the case facts.', 12);
for (let y = 0; y < 420; y += 30) {  // scroll the detail panel in small steps
  await page.evaluate((amt) => { document.getElementById('detail').scrollTop += amt; }, 30);
  await snap(1);
}
await snap(12);
await say('5  Account activity up to this transaction is shown, so the reviewer sees the pattern.', 12);
// 5. Escalate with a reason
await page.evaluate(() => { document.getElementById('detail').scrollTop = 0; });
await say('6  Give a reason, then escalate. The decision is saved with a timestamp.', 6);
await page.click('#note');
const reason = 'Four transfers between 9,650 and 9,990 MUR in four days, all just under the 10,000 MUR threshold. Escalate for review.';
for (let i = 0; i < reason.length; i += 3) {  // type the reason, a few characters per frame
  await page.keyboard.type(reason.slice(i, i + 3));
  await snap(1);
}
await snap(6);
await page.click('button[data-status="Escalated"]');
await say('7  The queue and the summary update at once. The audit trail records every decision.', 18);
// 6. Move through the queue with the arrow keys
await say('8  Use the arrow keys to move to the next case.', 6);
await page.keyboard.press('ArrowDown');
await snap(12);
// 7. Clear a case that has a plain explanation
await page.select('#fRisk', '');
await page.select('#fRule', 'HIGH_VALUE_DEBIT');
await snap(6);
await say('9  Filter by rule. Clear a case once the activity is explained.', 12);
await page.click('tr.case[data-id="CASE-0010"]');
await snap(12);
await page.click('#note');
const clearNote = 'Single transfer of 12,500 MUR, isolated in the period. Reviewed and cleared.';
for (let i = 0; i < clearNote.length; i += 4) {  // type the reason
  await page.keyboard.type(clearNote.slice(i, i + 4));
  await snap(1);
}
await snap(4);
await page.click('button[data-status="Cleared"]');
await say('10  Cleared cases stay in the audit trail, so the decision can be explained later.', 12);
// 8. Track status and export
await page.select('#fRule', '');
await page.select('#fStatus', 'Escalated');
await say('11  Filter by status to track the work. Export all decisions to CSV for the file.', 12);
await page.select('#fStatus', '');
await snap(6);
await page.click('#export');
await say('12  Open app/index.html in any browser. No server is needed, and no data leaves the machine.', 24);

await browser.close();
fs.writeFileSync(path.join(RAW, 'manifest.json'), JSON.stringify(manifest));
console.log('frames:', frame);

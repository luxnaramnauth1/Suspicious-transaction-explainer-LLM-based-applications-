window.SUSPICIOUS = {
 "meta": {
  "generated_from": "suspicious_transactions.csv",
  "rows_analysed": 220,
  "set_aside": 3,
  "mur_per_usd": 42.0,
  "high_value_mur": 10000,
  "weights": {
   "HIGH_VALUE_DEBIT": 35,
   "STRUCTURING": 55,
   "PASS_THROUGH": 40,
   "RAPID_SEQUENCE": 25,
   "OFF_HOURS": 15,
   "RETRY_AFTER_FAILURE": 20
  },
  "synthetic": true
 },
 "cases": [
  {
   "case_id": "CASE-0001",
   "transaction_id": "TXN0209",
   "account_id": "ACC2001",
   "customer_token": "cust_09f61913d4",
   "date": "2026-09-26 09:40",
   "amount": "22,008.33",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 75,
   "risk": "High",
   "note": "CASE-0001: flagged for review because of a debit of 22,008.33 MUR, at or above the 10,000 MUR review threshold; 22,008.33 MUR sent out 23.8 hours after a credit of 23,922.10 MUR, which is 92% of it. The transaction is 22,008.33 MUR on 2026-09-26 09:40, on account ACC2001. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "HIGH_VALUE_DEBIT",
     "weight": 35,
     "facts": {
      "amount": "22,008.33",
      "currency": "MUR",
      "threshold_mur": "10,000"
     }
    },
    {
     "rule": "PASS_THROUGH",
     "weight": 40,
     "facts": {
      "credit_amount": "23,922.10",
      "credit_id": "TXN0205",
      "debit_amount": "22,008.33",
      "currency": "MUR",
      "share_pct": 92,
      "hours": 23.8
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0169",
     "date": "2026-09-09 20:59",
     "type": "DEBIT",
     "amount": "232.57",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Pharmacy",
     "channel": "POS"
    },
    {
     "transaction_id": "TXN0174",
     "date": "2026-09-11 20:15",
     "type": "CREDIT",
     "amount": "3,891.49",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer In",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0199",
     "date": "2026-09-25 07:37",
     "type": "DEBIT",
     "amount": "1,225.07",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0205",
     "date": "2026-09-25 09:50",
     "type": "CREDIT",
     "amount": "23,922.10",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Salary",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0209",
     "date": "2026-09-26 09:40",
     "type": "DEBIT",
     "amount": "22,008.33",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0002",
   "transaction_id": "TXN0180",
   "account_id": "ACC2003",
   "customer_token": "cust_bac0dd1336",
   "date": "2026-09-14 10:15",
   "amount": "9,800.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 55,
   "risk": "High",
   "note": "CASE-0002: flagged for review because of 4 debits between 9,000-9,999 MUR within 7 days totalling 39,340.00 MUR, just under the review threshold. The transaction is 9,800.00 MUR on 2026-09-14 10:15, on account ACC2003. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "STRUCTURING",
     "weight": 55,
     "facts": {
      "count": 4,
      "total_mur": "39,340.00",
      "band": "9,000-9,999 MUR",
      "days": 7,
      "related": [
       "TXN0180",
       "TXN0181",
       "TXN0184",
       "TXN0186"
      ]
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0135",
     "date": "2026-08-30 14:17",
     "type": "DEBIT",
     "amount": "329.60",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Health",
     "channel": "POS"
    },
    {
     "transaction_id": "TXN0144",
     "date": "2026-08-31 20:12",
     "type": "DEBIT",
     "amount": "113.71",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Streaming",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0158",
     "date": "2026-09-06 11:44",
     "type": "DEBIT",
     "amount": "340.96",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Utilities",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0161",
     "date": "2026-09-07 11:30",
     "type": "DEBIT",
     "amount": "1,115.43",
     "currency": "MUR",
     "status": "FAILED",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0180",
     "date": "2026-09-14 10:15",
     "type": "DEBIT",
     "amount": "9,800.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0003",
   "transaction_id": "TXN0181",
   "account_id": "ACC2003",
   "customer_token": "cust_bac0dd1336",
   "date": "2026-09-15 10:15",
   "amount": "9,900.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 55,
   "risk": "High",
   "note": "CASE-0003: flagged for review because of 4 debits between 9,000-9,999 MUR within 7 days totalling 39,340.00 MUR, just under the review threshold. The transaction is 9,900.00 MUR on 2026-09-15 10:15, on account ACC2003. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "STRUCTURING",
     "weight": 55,
     "facts": {
      "count": 4,
      "total_mur": "39,340.00",
      "band": "9,000-9,999 MUR",
      "days": 7,
      "related": [
       "TXN0180",
       "TXN0181",
       "TXN0184",
       "TXN0186"
      ]
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0144",
     "date": "2026-08-31 20:12",
     "type": "DEBIT",
     "amount": "113.71",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Streaming",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0158",
     "date": "2026-09-06 11:44",
     "type": "DEBIT",
     "amount": "340.96",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Utilities",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0161",
     "date": "2026-09-07 11:30",
     "type": "DEBIT",
     "amount": "1,115.43",
     "currency": "MUR",
     "status": "FAILED",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0180",
     "date": "2026-09-14 10:15",
     "type": "DEBIT",
     "amount": "9,800.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0181",
     "date": "2026-09-15 10:15",
     "type": "DEBIT",
     "amount": "9,900.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0004",
   "transaction_id": "TXN0184",
   "account_id": "ACC2003",
   "customer_token": "cust_bac0dd1336",
   "date": "2026-09-16 10:15",
   "amount": "9,650.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 55,
   "risk": "High",
   "note": "CASE-0004: flagged for review because of 4 debits between 9,000-9,999 MUR within 7 days totalling 39,340.00 MUR, just under the review threshold. The transaction is 9,650.00 MUR on 2026-09-16 10:15, on account ACC2003. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "STRUCTURING",
     "weight": 55,
     "facts": {
      "count": 4,
      "total_mur": "39,340.00",
      "band": "9,000-9,999 MUR",
      "days": 7,
      "related": [
       "TXN0180",
       "TXN0181",
       "TXN0184",
       "TXN0186"
      ]
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0158",
     "date": "2026-09-06 11:44",
     "type": "DEBIT",
     "amount": "340.96",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Utilities",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0161",
     "date": "2026-09-07 11:30",
     "type": "DEBIT",
     "amount": "1,115.43",
     "currency": "MUR",
     "status": "FAILED",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0180",
     "date": "2026-09-14 10:15",
     "type": "DEBIT",
     "amount": "9,800.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0181",
     "date": "2026-09-15 10:15",
     "type": "DEBIT",
     "amount": "9,900.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0184",
     "date": "2026-09-16 10:15",
     "type": "DEBIT",
     "amount": "9,650.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0005",
   "transaction_id": "TXN0186",
   "account_id": "ACC2003",
   "customer_token": "cust_bac0dd1336",
   "date": "2026-09-17 10:15",
   "amount": "9,990.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 55,
   "risk": "High",
   "note": "CASE-0005: flagged for review because of 4 debits between 9,000-9,999 MUR within 7 days totalling 39,340.00 MUR, just under the review threshold. The transaction is 9,990.00 MUR on 2026-09-17 10:15, on account ACC2003. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "STRUCTURING",
     "weight": 55,
     "facts": {
      "count": 4,
      "total_mur": "39,340.00",
      "band": "9,000-9,999 MUR",
      "days": 7,
      "related": [
       "TXN0180",
       "TXN0181",
       "TXN0184",
       "TXN0186"
      ]
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0161",
     "date": "2026-09-07 11:30",
     "type": "DEBIT",
     "amount": "1,115.43",
     "currency": "MUR",
     "status": "FAILED",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0180",
     "date": "2026-09-14 10:15",
     "type": "DEBIT",
     "amount": "9,800.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0181",
     "date": "2026-09-15 10:15",
     "type": "DEBIT",
     "amount": "9,900.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0184",
     "date": "2026-09-16 10:15",
     "type": "DEBIT",
     "amount": "9,650.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0186",
     "date": "2026-09-17 10:15",
     "type": "DEBIT",
     "amount": "9,990.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0006",
   "transaction_id": "TXN0137",
   "account_id": "ACC2004",
   "customer_token": "cust_ed0c7a1158",
   "date": "2026-08-30 23:10",
   "amount": "2,850.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "ONLINE",
   "category": "Electronics",
   "score": 40,
   "risk": "Medium",
   "note": "CASE-0006: flagged for review because of 4 debits on this account within 60 minutes; a debit of 2,850.00 MUR at 23:10, outside the 05:00 to 23:00 window. The transaction is 2,850.00 MUR on 2026-08-30 23:10, on account ACC2004. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "RAPID_SEQUENCE",
     "weight": 25,
     "facts": {
      "count": 4,
      "minutes": 60,
      "related": [
       "TXN0137",
       "TXN0138",
       "TXN0139",
       "TXN0140"
      ]
     }
    },
    {
     "rule": "OFF_HOURS",
     "weight": 15,
     "facts": {
      "time": "23:10",
      "amount": "2,850.00",
      "currency": "MUR",
      "window": "05:00 to 23:00"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0117",
     "date": "2026-08-25 09:15",
     "type": "CREDIT",
     "amount": "30,174.42",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Salary",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0120",
     "date": "2026-08-25 18:58",
     "type": "DEBIT",
     "amount": "169.64",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Pharmacy",
     "channel": "POS"
    },
    {
     "transaction_id": "TXN0126",
     "date": "2026-08-28 07:08",
     "type": "DEBIT",
     "amount": "394.25",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Entertainment",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0131",
     "date": "2026-08-29 15:58",
     "type": "DEBIT",
     "amount": "252.32",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Restaurant",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0137",
     "date": "2026-08-30 23:10",
     "type": "DEBIT",
     "amount": "2,850.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    }
   ]
  },
  {
   "case_id": "CASE-0007",
   "transaction_id": "TXN0138",
   "account_id": "ACC2004",
   "customer_token": "cust_ed0c7a1158",
   "date": "2026-08-30 23:22",
   "amount": "3,120.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "ONLINE",
   "category": "Electronics",
   "score": 40,
   "risk": "Medium",
   "note": "CASE-0007: flagged for review because of 4 debits on this account within 60 minutes; a debit of 3,120.00 MUR at 23:22, outside the 05:00 to 23:00 window. The transaction is 3,120.00 MUR on 2026-08-30 23:22, on account ACC2004. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "RAPID_SEQUENCE",
     "weight": 25,
     "facts": {
      "count": 4,
      "minutes": 60,
      "related": [
       "TXN0137",
       "TXN0138",
       "TXN0139",
       "TXN0140"
      ]
     }
    },
    {
     "rule": "OFF_HOURS",
     "weight": 15,
     "facts": {
      "time": "23:22",
      "amount": "3,120.00",
      "currency": "MUR",
      "window": "05:00 to 23:00"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0120",
     "date": "2026-08-25 18:58",
     "type": "DEBIT",
     "amount": "169.64",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Pharmacy",
     "channel": "POS"
    },
    {
     "transaction_id": "TXN0126",
     "date": "2026-08-28 07:08",
     "type": "DEBIT",
     "amount": "394.25",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Entertainment",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0131",
     "date": "2026-08-29 15:58",
     "type": "DEBIT",
     "amount": "252.32",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Restaurant",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0137",
     "date": "2026-08-30 23:10",
     "type": "DEBIT",
     "amount": "2,850.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0138",
     "date": "2026-08-30 23:22",
     "type": "DEBIT",
     "amount": "3,120.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    }
   ]
  },
  {
   "case_id": "CASE-0008",
   "transaction_id": "TXN0139",
   "account_id": "ACC2004",
   "customer_token": "cust_ed0c7a1158",
   "date": "2026-08-30 23:31",
   "amount": "2,990.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "ONLINE",
   "category": "Electronics",
   "score": 40,
   "risk": "Medium",
   "note": "CASE-0008: flagged for review because of 4 debits on this account within 60 minutes; a debit of 2,990.00 MUR at 23:31, outside the 05:00 to 23:00 window. The transaction is 2,990.00 MUR on 2026-08-30 23:31, on account ACC2004. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "RAPID_SEQUENCE",
     "weight": 25,
     "facts": {
      "count": 4,
      "minutes": 60,
      "related": [
       "TXN0137",
       "TXN0138",
       "TXN0139",
       "TXN0140"
      ]
     }
    },
    {
     "rule": "OFF_HOURS",
     "weight": 15,
     "facts": {
      "time": "23:31",
      "amount": "2,990.00",
      "currency": "MUR",
      "window": "05:00 to 23:00"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0126",
     "date": "2026-08-28 07:08",
     "type": "DEBIT",
     "amount": "394.25",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Entertainment",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0131",
     "date": "2026-08-29 15:58",
     "type": "DEBIT",
     "amount": "252.32",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Restaurant",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0137",
     "date": "2026-08-30 23:10",
     "type": "DEBIT",
     "amount": "2,850.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0138",
     "date": "2026-08-30 23:22",
     "type": "DEBIT",
     "amount": "3,120.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0139",
     "date": "2026-08-30 23:31",
     "type": "DEBIT",
     "amount": "2,990.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    }
   ]
  },
  {
   "case_id": "CASE-0009",
   "transaction_id": "TXN0140",
   "account_id": "ACC2004",
   "customer_token": "cust_ed0c7a1158",
   "date": "2026-08-30 23:45",
   "amount": "3,400.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "ONLINE",
   "category": "Electronics",
   "score": 40,
   "risk": "Medium",
   "note": "CASE-0009: flagged for review because of 4 debits on this account within 60 minutes; a debit of 3,400.00 MUR at 23:45, outside the 05:00 to 23:00 window. The transaction is 3,400.00 MUR on 2026-08-30 23:45, on account ACC2004. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "RAPID_SEQUENCE",
     "weight": 25,
     "facts": {
      "count": 4,
      "minutes": 60,
      "related": [
       "TXN0137",
       "TXN0138",
       "TXN0139",
       "TXN0140"
      ]
     }
    },
    {
     "rule": "OFF_HOURS",
     "weight": 15,
     "facts": {
      "time": "23:45",
      "amount": "3,400.00",
      "currency": "MUR",
      "window": "05:00 to 23:00"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0131",
     "date": "2026-08-29 15:58",
     "type": "DEBIT",
     "amount": "252.32",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Restaurant",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0137",
     "date": "2026-08-30 23:10",
     "type": "DEBIT",
     "amount": "2,850.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0138",
     "date": "2026-08-30 23:22",
     "type": "DEBIT",
     "amount": "3,120.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0139",
     "date": "2026-08-30 23:31",
     "type": "DEBIT",
     "amount": "2,990.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0140",
     "date": "2026-08-30 23:45",
     "type": "DEBIT",
     "amount": "3,400.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    }
   ]
  },
  {
   "case_id": "CASE-0010",
   "transaction_id": "TXN0090",
   "account_id": "ACC2002",
   "customer_token": "cust_6de94e44ff",
   "date": "2026-08-14 11:02",
   "amount": "12,500.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 35,
   "risk": "Medium",
   "note": "CASE-0010: flagged for review because of a debit of 12,500.00 MUR, at or above the 10,000 MUR review threshold. The transaction is 12,500.00 MUR on 2026-08-14 11:02, on account ACC2002. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "HIGH_VALUE_DEBIT",
     "weight": 35,
     "facts": {
      "amount": "12,500.00",
      "currency": "MUR",
      "threshold_mur": "10,000"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0068",
     "date": "2026-08-03 20:58",
     "type": "CREDIT",
     "amount": "3,505.08",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer In",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0077",
     "date": "2026-08-09 19:17",
     "type": "CREDIT",
     "amount": "84.08",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Cashback",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0079",
     "date": "2026-08-10 07:07",
     "type": "DEBIT",
     "amount": "394.34",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Entertainment",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0085",
     "date": "2026-08-13 12:46",
     "type": "DEBIT",
     "amount": "334.43",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Utilities",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0090",
     "date": "2026-08-14 11:02",
     "type": "DEBIT",
     "amount": "12,500.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0011",
   "transaction_id": "TXN0150",
   "account_id": "ACC2004",
   "customer_token": "cust_ed0c7a1158",
   "date": "2026-09-03 15:40",
   "amount": "10,800.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Transfer Out",
   "score": 35,
   "risk": "Medium",
   "note": "CASE-0011: flagged for review because of a debit of 10,800.00 MUR, at or above the 10,000 MUR review threshold. The transaction is 10,800.00 MUR on 2026-09-03 15:40, on account ACC2004. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "HIGH_VALUE_DEBIT",
     "weight": 35,
     "facts": {
      "amount": "10,800.00",
      "currency": "MUR",
      "threshold_mur": "10,000"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0140",
     "date": "2026-08-30 23:45",
     "type": "DEBIT",
     "amount": "3,400.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0141",
     "date": "2026-08-31 11:21",
     "type": "CREDIT",
     "amount": "118.91",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Refund",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0148",
     "date": "2026-09-01 20:34",
     "type": "DEBIT",
     "amount": "247.39",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Restaurant",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0149",
     "date": "2026-09-03 08:15",
     "type": "DEBIT",
     "amount": "2,732.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Electronics",
     "channel": "ONLINE"
    },
    {
     "transaction_id": "TXN0150",
     "date": "2026-09-03 15:40",
     "type": "DEBIT",
     "amount": "10,800.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer Out",
     "channel": "TRANSFER"
    }
   ]
  },
  {
   "case_id": "CASE-0012",
   "transaction_id": "TXN0166",
   "account_id": "ACC2002",
   "customer_token": "cust_6de94e44ff",
   "date": "2026-09-08 15:05",
   "amount": "5,000.00",
   "currency": "MUR",
   "type": "DEBIT",
   "status": "SUCCESS",
   "channel": "TRANSFER",
   "category": "Insurance",
   "score": 20,
   "risk": "Low",
   "note": "CASE-0012: flagged for review because of the same amount, 5,000.00 MUR, succeeded 63 minutes after a failed attempt. The transaction is 5,000.00 MUR on 2026-09-08 15:05, on account ACC2002. Draft for analyst review.",
   "note_source": "template",
   "rules": [
    {
     "rule": "RETRY_AFTER_FAILURE",
     "weight": 20,
     "facts": {
      "amount": "5,000.00",
      "currency": "MUR",
      "minutes": 63,
      "failed_id": "TXN0165"
     }
    }
   ],
   "context": [
    {
     "transaction_id": "TXN0146",
     "date": "2026-09-01 14:39",
     "type": "DEBIT",
     "amount": "34.74",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transport",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0156",
     "date": "2026-09-05 10:09",
     "type": "DEBIT",
     "amount": "687.45",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Health",
     "channel": "POS"
    },
    {
     "transaction_id": "TXN0159",
     "date": "2026-09-06 19:44",
     "type": "CREDIT",
     "amount": "3,224.47",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Transfer In",
     "channel": "MOBILE"
    },
    {
     "transaction_id": "TXN0165",
     "date": "2026-09-08 14:02",
     "type": "DEBIT",
     "amount": "5,000.00",
     "currency": "MUR",
     "status": "FAILED",
     "category": "Insurance",
     "channel": "TRANSFER"
    },
    {
     "transaction_id": "TXN0166",
     "date": "2026-09-08 15:05",
     "type": "DEBIT",
     "amount": "5,000.00",
     "currency": "MUR",
     "status": "SUCCESS",
     "category": "Insurance",
     "channel": "TRANSFER"
    }
   ]
  }
 ]
};
